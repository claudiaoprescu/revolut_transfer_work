package main.java.com.db;

public abstract class ConnectionTypes {
	
	private static String url;
	private static String user;
	private static String pass;
	private static String driver;

	public ConnectionTypes() {

	}
	
	public String description(){
		return "Generic";
	}

	public static String getUrl() {
		return url;
	}

	public static void setUrl(String url) {
		ConnectionTypes.url = url;
	}

	public static String getUser() {
		return user;
	}

	public static void setUser(String user) {
		ConnectionTypes.user = user;
	}

	public static String getPass() {
		return pass;
	}

	public static void setPass(String pass) {
		ConnectionTypes.pass = pass;
	}

	public static String getDriver() {
		return driver;
	}

	public static void setDriver(String driver) {
		ConnectionTypes.driver = driver;
	}

	
}
