package main.java.com.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * 
 * @author claudia.oprescu
 * 
 *         Data access Object class
 *
 */

public class DBDAO {

	private static Connection con;

	public DBDAO(Connection con) {
		DBDAO.con = con;
	}

	public Connection getCon() {
		return con;
	}

	public void setCon(Connection con) {
		DBDAO.con = con;
	}

	public ResultSet readUserTable() throws SQLException {
		System.out.println(SqlQueries.READUSER.getSQL());
		return con.prepareStatement(SqlQueries.READUSER.getSQL())
				.executeQuery();
	}

	public ResultSet readAccountTable() throws SQLException {
		return con.prepareStatement(SqlQueries.READACCOUNT.getSQL())
				.executeQuery();
	}

	public ResultSet readTransactionTable() throws SQLException {
		return con.prepareStatement(SqlQueries.READTRANSACTION.getSQL())
				.executeQuery();
	}

	public void writeUserTable(String userName) throws SQLException {
		PreparedStatement statement = con
				.prepareStatement(SqlQueries.INSERTUSER.getSQL());
		statement.setString(1, userName);
		statement.executeUpdate();
		statement.close();
		con.commit();

	}

	public void writeAccountTable(Integer userid, Integer amount)
			throws SQLException {
		PreparedStatement statement = con
				.prepareStatement(SqlQueries.INSERTACCOUNT.getSQL());
		statement.setInt(1, amount);
		statement.setInt(2, userid);
		statement.executeUpdate();
		statement.close();
		con.commit();

	}

	public Integer writeTransactionTable(Integer amount, Integer fromAcc,
			Integer toAcc, String status) throws SQLException {
		PreparedStatement statement = con.prepareStatement(
				SqlQueries.INSERTTRANSACTION.getSQL(),
				Statement.RETURN_GENERATED_KEYS);
		statement.setInt(1, amount);
		statement.setInt(2, fromAcc);
		statement.setInt(3, toAcc);
		statement.setString(4, status);
		statement.executeUpdate();
		Integer transactionId = null;
		try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
			if (generatedKeys.next()) {
				transactionId = generatedKeys.getInt(1);
			} else {
				throw new SQLException(
						"Creating transaction failed, no ID obtained.");
			}
		}

		statement.close();

		return transactionId;

	}

	public void createUserTable() throws SQLException {
		PreparedStatement statement = con
				.prepareStatement(SqlQueries.CREATEUSERTABLE.getSQL());
		statement.executeUpdate();
		statement.close();
		con.commit();

	}

	public void createAccountTable() throws SQLException {
		PreparedStatement acc = con
				.prepareStatement(SqlQueries.CREATEACCOUNTSTABLE.getSQL());
		acc.executeUpdate();

		PreparedStatement fk = con.prepareStatement(SqlQueries.SETFKUSERACCOUNT
				.getSQL());
		fk.executeUpdate();

		PreparedStatement pos = con
				.prepareStatement(SqlQueries.SETPOSITIVEAMOUNTCONSTRAINT
						.getSQL());
		pos.executeUpdate();

		acc.close();
		fk.close();
		pos.close();

		con.commit();

	}

	public void createTransactionTable() throws SQLException {
		PreparedStatement tra = con
				.prepareStatement(SqlQueries.CREATETRANSACTIONTABLE.getSQL());
		tra.executeUpdate();

		PreparedStatement fkf = con
				.prepareStatement(SqlQueries.SETFKFROMACCOUNT.getSQL());
		fkf.executeUpdate();

		PreparedStatement fkt = con.prepareStatement(SqlQueries.SETFKTOACCOUNT
				.getSQL());
		fkt.executeUpdate();

		PreparedStatement pos = con
				.prepareStatement(SqlQueries.SETPOSITIVEAMOUNT1.getSQL());
		pos.executeUpdate();

		tra.close();
		fkf.close();
		fkt.close();
		pos.close();

		con.commit();

	}

	public ResultSet getAccountAmount(Integer accountid) throws SQLException {
		PreparedStatement statement = con
				.prepareStatement(SqlQueries.READACCOUNTAMOUNT.getSQL());
		statement.setInt(1, accountid);
		ResultSet rs = statement.executeQuery();
		statement.close();
		return rs;
	}

	public void setAccountAmount(Integer amount, Integer accountid)
			throws SQLException {
		PreparedStatement statement = con
				.prepareStatement(SqlQueries.UPDATEACCOUNTAMOUNT.getSQL());
		statement.setInt(1, amount);
		statement.setInt(2, accountid);
		statement.executeUpdate();
		statement.close();

	}

	public void updateTransactionStatus(String status, Integer transactionid)
			throws SQLException {
		PreparedStatement statement = con
				.prepareStatement(SqlQueries.UPDATETRANSACTIONSTATUS.getSQL());
		statement.setString(1, status);
		statement.setInt(2, transactionid);
		statement.executeUpdate();
		statement.close();

	}
}
