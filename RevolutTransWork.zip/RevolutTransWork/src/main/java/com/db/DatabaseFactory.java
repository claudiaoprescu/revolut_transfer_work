package main.java.com.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import main.java.com.util.Constants;

import org.apache.log4j.Logger;

public class DatabaseFactory {

	final static Class<DatabaseFactory> CLASS_NAME = DatabaseFactory.class;
	final static Logger logger = Logger.getLogger(CLASS_NAME);
	protected String type;

	public DatabaseFactory(String t) {
		type = t;
	}

	public ConnectionTypes createConnection() {
		if (type.equals(Constants.DB_NAME))
			return new HSQLDBConnection();
		else
			return new OtherConnection();
	}

	public Connection initializeConnection() {
		Connection c = null;
		try {
			Class.forName(ConnectionTypes.getDriver());
			c = DriverManager.getConnection(ConnectionTypes.getUrl(),
					ConnectionTypes.getUser(), ConnectionTypes.getPass());
			c.setAutoCommit(false);
			logger.info("connection success!!" + c.getSchema());
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException ex) {
			ex.printStackTrace();
		}

		return c;

	}

	public void initializeDB(DBDAO dbDao) {

		try {
			dbDao.createUserTable();
			logger.info("created user table");
			dbDao.writeUserTable("Monica");
			dbDao.writeUserTable("John");
			dbDao.writeUserTable("Rachel");

			logger.info(dbDao.readUserTable());

			dbDao.createAccountTable();
			logger.info("created account table");
			dbDao.writeAccountTable(1, 100);
			dbDao.writeAccountTable(2, 200);
			dbDao.writeAccountTable(3, 1020);
			logger.info(dbDao.readAccountTable());

			dbDao.createTransactionTable();
			logger.info("created transaction table");
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
}
