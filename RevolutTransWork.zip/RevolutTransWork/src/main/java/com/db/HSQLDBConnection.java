package main.java.com.db;

public class HSQLDBConnection extends ConnectionTypes {

	public HSQLDBConnection() {
		setUrl("jdbc:hsqldb:mem:hsqldb;shutdown=true;hsqldb.write_delay=false;hsqldb.sqllog=3");
		setUser("sa");
		setPass("");
		setDriver("org.hsqldb.jdbcDriver");
	}

}
