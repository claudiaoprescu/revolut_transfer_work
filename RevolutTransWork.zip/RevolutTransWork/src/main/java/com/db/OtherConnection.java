package main.java.com.db;


public class OtherConnection extends ConnectionTypes {

	public OtherConnection() {

	}

	public String description() {
		return "OTHER";
	}

}
