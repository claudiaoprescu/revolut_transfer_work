package main.java.com.exception;

public class AccountDoesNotExistException extends Exception {

	private static final long serialVersionUID = 5617770350567496322L;

	/**
	 * Custom defined error
	 * 
	 * @param String
	 *            message
	 * @throws AccountDoesNotExistException
	 */

	public AccountDoesNotExistException(String message) throws AccountDoesNotExistException {
		super("Account Doesn't Exist: " + message);
	}

}
