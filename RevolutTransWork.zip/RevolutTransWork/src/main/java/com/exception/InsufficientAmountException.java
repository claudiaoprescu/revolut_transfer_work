package main.java.com.exception;

public class InsufficientAmountException extends Exception {

	private static final long serialVersionUID = 5617770350567496322L;

	/**
	 * Custom defined error
	 * 
	 * @param String
	 *            message
	 * @throws InsufficientAmountException
	 */

	public InsufficientAmountException(String message)
			throws InsufficientAmountException {
		super(
				"The account specified does not have sufficient funds for the withdrawl requested, amount available: "
						+ message);
	}

}
