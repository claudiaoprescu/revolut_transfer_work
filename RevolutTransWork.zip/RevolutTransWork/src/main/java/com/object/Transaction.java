package main.java.com.object;

public class Transaction {

	private Integer toAccountid;
	private Integer fromAcctountid;
	private Integer amount;

	public Transaction(Integer fromAcctountid , Integer toAccountid,
			Integer amount) {
		this.toAccountid = toAccountid;
		this.fromAcctountid = fromAcctountid;
		this.amount = amount;
	}

	public Integer getToAccountid() {
		return toAccountid;
	}

	public void setToAccountid(Integer toAccountid) {
		this.toAccountid = toAccountid;
	}

	public Integer getFromAcctountid() {
		return fromAcctountid;
	}

	public void setFromAcctountid(Integer fromAcctountid) {
		this.fromAcctountid = fromAcctountid;
	}

	public Integer getAmount() {
		return amount;
	}

	public void setAmount(Integer amount) {
		this.amount = amount;
	}

}
