package main.java.com.operation;

import java.sql.ResultSet;
import java.sql.SQLException;

import main.java.com.db.DBDAO;
import main.java.com.exception.AccountDoesNotExistException;
import main.java.com.exception.InsufficientAmountException;
import main.java.com.object.Transaction;
import main.java.com.util.TransactionStatus;

public class TransactionOperation {

	public static Transaction validateTransaction(DBDAO dbDao, Integer fromAcc,
			Integer toAcc, Integer amount) throws SQLException,
			AccountDoesNotExistException, InsufficientAmountException {

		ResultSet rs = dbDao.getAccountAmount(fromAcc);

		if (!rs.next()) {
			throw new AccountDoesNotExistException(fromAcc.toString());
		}

		else if (!dbDao.getAccountAmount(toAcc).next()) {
			throw new AccountDoesNotExistException(toAcc.toString());
		}

		else if (rs.getInt(1) - amount < 0) {
			throw new InsufficientAmountException(String.valueOf(rs.getInt(1)));
		}

		return new Transaction(fromAcc, toAcc, amount);

	}

	public static void performTransaction(DBDAO dbDao, Transaction trans)
			throws SQLException {

		Integer amountToUpdate;
		Integer transactionId;
		ResultSet rs;
		// insert into transaction
		try {
			transactionId = dbDao.writeTransactionTable(trans.getAmount(),
					trans.getFromAcctountid(), trans.getToAccountid(),
					TransactionStatus.INPRG.getStatusValue());

			// update from account
			rs = dbDao.getAccountAmount(trans.getFromAcctountid());
			rs.next();
			amountToUpdate = rs.getInt(1) - trans.getAmount();
			dbDao.setAccountAmount(amountToUpdate, trans.getFromAcctountid());

			// update to account
			rs = dbDao.getAccountAmount(trans.getToAccountid());
			rs.next();
			amountToUpdate = rs.getInt(1) + trans.getAmount();
			dbDao.setAccountAmount(amountToUpdate, trans.getToAccountid());

			// update transaction with status=DONE
			dbDao.updateTransactionStatus(
					TransactionStatus.DONE.getStatusValue(), transactionId);
			dbDao.getCon().commit();
		} catch (SQLException e) {
			dbDao.getCon().rollback();
			e.printStackTrace();
		}

	}
}
