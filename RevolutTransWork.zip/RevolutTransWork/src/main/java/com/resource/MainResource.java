package main.java.com.resource;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import main.java.com.db.DBDAO;
import main.java.com.db.DatabaseFactory;
import main.java.com.db.SqlQueries;
import main.java.com.exception.AccountDoesNotExistException;
import main.java.com.exception.InsufficientAmountException;
import main.java.com.object.Transaction;
import main.java.com.operation.TransactionOperation;
import main.java.com.util.Constants;
import main.java.com.util.ResultSetConvertToJSON;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainResource extends HttpServlet {

	private static final long serialVersionUID = 3557460191500040751L;
	DBDAO dbDao;
	Connection con;

	public void init() throws ServletException {
		DatabaseFactory db = new DatabaseFactory(Constants.DB_NAME);
		db.createConnection();
		this.con = db.initializeConnection();

		this.dbDao = new DBDAO(con);
		db.initializeDB(dbDao);
	}

	public void destroy() {
		// hsqldb needs shutdown
		try {
			con.createStatement().execute(SqlQueries.SHUTDOWN.getSQL());
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {

		String requestURL = req.getRequestURL().toString();

		ResultSet rs = null;
		JSONArray result = null;
		try {
			if (requestURL.contains(Constants.USER_URL)) {
				rs = dbDao.readUserTable();
			} else if (requestURL.contains(Constants.ACCOUNT_URL)) {
				rs = dbDao.readAccountTable();
			} else if (requestURL.contains(Constants.TRANSACTION_URL)) {
				rs = dbDao.readTransactionTable();
			} else {
				res.setStatus(HttpServletResponse.SC_BAD_REQUEST);
				throw new ServletException("BAD REQUEST: " + requestURL);
			}

			result = ResultSetConvertToJSON.convert(rs);

		} catch (Exception e) {
			e.printStackTrace();
		}

		res.setContentType("application/json");
		// Get the printwriter object from response to write the required json
		// object to the output stream
		PrintWriter out = res.getWriter();
		out.print(result);
		out.flush();
	}

	public void doPut(HttpServletRequest req, HttpServletResponse res) {

		String stringBr = new String();

		try {
			// Read from request
			BufferedReader br = req.getReader();
			for (String line; (line = br.readLine()) != null; stringBr += line)
				;

			// Transform result into JSONObject
			JSONObject request = new JSONObject(stringBr);

			// Get params from JSONObject
			Integer from = request.getInt(Constants.FROM_PARAM);
			Integer to = request.getInt(Constants.TO_PARAM);
			Integer amount = request.getInt(Constants.AMOUNT_PARAM);

			// Start performing operations
			Transaction trans = TransactionOperation.validateTransaction(dbDao,
					from, to, amount);
			TransactionOperation.performTransaction(dbDao, trans);
			res.setStatus(HttpServletResponse.SC_OK);
		} catch (JSONException | IOException | SQLException
				| AccountDoesNotExistException | InsufficientAmountException e) {
			res.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			e.printStackTrace();
		}
	}
}
