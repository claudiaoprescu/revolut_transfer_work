package main.java.com.test;

import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.fail;
import static org.junit.Assert.assertThat;

import java.sql.Connection;

import main.java.com.db.DBDAO;
import main.java.com.db.DatabaseFactory;
import main.java.com.operation.TransactionOperation;
import main.java.com.util.Constants;

import org.junit.Test;

public class UnitTest {

	Connection con;
	DBDAO dbDao;

	@Test
	public void testAmount() {
		init();
		try {
			TransactionOperation.validateTransaction(dbDao, 1, 2, 50000);
			fail("Exception Expected");
		} catch (Exception e) {
			assertThat(
					e.getMessage(),
					containsString("account specified does not have sufficient funds"));
		}

	}

	@Test
	public void testToAccount() {
		init();
		try {
			TransactionOperation.validateTransaction(dbDao, 1, 75, 50);
			fail("Exception Expected");
		} catch (Exception e) {
			assertThat(e.getMessage(), containsString("Account Doesn't Exist"));
		}

	}

	@Test
	public void testFromAccount() {
		init();
		try {
			TransactionOperation.validateTransaction(dbDao, 75, 1, 50);
			fail("Exception Expected");
		} catch (Exception e) {
			assertThat(e.getMessage(), containsString("Account Doesn't Exist"));
		}

	}

	private void init() {
		DatabaseFactory db = new DatabaseFactory(Constants.DB_NAME);
		db.createConnection();
		this.con = db.initializeConnection();

		this.dbDao = new DBDAO(con);
		db.initializeDB(dbDao);
	}

}
