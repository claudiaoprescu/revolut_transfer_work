package main.java.com.util;

public class Constants {

	public static final String DB_NAME = "HSQLDB";

	public static final String FROM_PARAM = "from";
	public static final String TO_PARAM = "to";
	public static final String AMOUNT_PARAM = "amount";

	public static final String USER_URL = "/user";
	public static final String ACCOUNT_URL = "/account";
	public static final String TRANSACTION_URL = "/transaction";

}
