package main.java.com.util;

import main.java.com.db.DatabaseFactory;
import main.java.com.resource.MainResource;

import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletHandler;

/**
 * 
 * @author CEO
 * @version v01 Transactions
 * @since 07/15/2017<br>
 *
 */

public class StartProgram {

	public static void main(String[] args) throws Exception {

		DatabaseFactory db = new DatabaseFactory(Constants.DB_NAME);
		db.createConnection();
		db.initializeConnection();

		ServletHandler handler = new ServletHandler();

		Server server = new Server(8080);
		server.setHandler(handler);
		handler.addServletWithMapping(MainResource.class, "/*");

		try {
			server.start();
			server.join();
		} finally {
			server.destroy();

		}

	}

}
