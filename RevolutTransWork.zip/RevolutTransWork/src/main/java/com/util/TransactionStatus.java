package main.java.com.util;

public enum TransactionStatus {

	INPRG("INPRG"), DONE("DONE");

	TransactionStatus(String statusValue) {
		this.statusValue = statusValue;
	}

	String statusValue;

	public String getStatusValue() {
		return statusValue;
	}

	public void setStatusValue(String statusValue) {
		this.statusValue = statusValue;
	}

}
